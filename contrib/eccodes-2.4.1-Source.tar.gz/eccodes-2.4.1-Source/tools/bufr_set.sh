#!/bin/sh

echo "-# Set key <i>bufrHeaderCentre</i> in the header and print its value after the change:  \\n"
echo "\\verbatim "
echo "> bufr_set -v -p bufrHeaderCentre -s bufrHeaderCentre=222  ../data/bufr/syno_1.bufr out.bufr \\n"
echo "\\endverbatim\\n "
