./timing ../data/reduced_latlon_surface.grib1 > /dev/null
